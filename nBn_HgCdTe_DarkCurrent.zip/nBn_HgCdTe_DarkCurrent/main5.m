%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Physics-Based Modeling of Dark Current Reduction in nBn HgCdTe Detector
% PART 1
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clc
clear
close all

%% ========================================================================
% PHYSICAL CONSTANTS
% ========================================================================

q = 1.602e-19;          % Electron Charge (C)
k = 8.617e-5;           % Boltzmann Constant (eV/K)
h = 6.626e-34;          % Planck Constant
c = 3e8;                % Speed of Light
eps0 = 8.854e-14;       % Permittivity (F/cm)

%% ========================================================================
% DEVICE PARAMETERS
% ========================================================================

x = 0.23;               % Cd Composition
Area = 25e-4*25e-4;     % Detector Area (cm^2)

%% ========================================================================
% TEMPERATURE RANGE
% ========================================================================

T = 77:5:300;

%% ========================================================================
% BANDGAP OF HgCdTe
% ========================================================================

Eg = -0.302 + 1.93*x ...
    -0.81*x^2 ...
    +5.35e-4*T.*(1-2*x);

%% ========================================================================
% BANDGAP GRAPH
% ========================================================================

figure

plot(T,Eg,'r','LineWidth',3)

grid on
box on

xlabel('Temperature (K)')
ylabel('Bandgap (eV)')

title('HgCdTe Bandgap')

set(gca,'FontSize',12)

%% ========================================================================
% DIFFUSION CURRENT
% ========================================================================

A = 1e-4;

Jdiff = A .* (T.^3) .* exp(-Eg./(k*T));

%% ========================================================================
% DIFFUSION GRAPH
% ========================================================================

figure

semilogy(T,Jdiff,'r','LineWidth',2)

grid on
box on

xlabel('Temperature (K)')
ylabel('Current (A/cm^2)')

title('Diffusion Current')

set(gca,'FontSize',12)

%% ========================================================================
% SRH CURRENT
% ========================================================================

B = 5e-7;

Jsrh = B .* (T.^2) .* exp(-Eg./(2*k*T));

%% ========================================================================
% SRH GRAPH
% ========================================================================

figure

semilogy(T,Jsrh,'b','LineWidth',2)

grid on
box on

xlabel('Temperature (K)')
ylabel('Current (A/cm^2)')

title('SRH Current')

set(gca,'FontSize',12)

%% ========================================================================
% DIFFUSION vs SRH
% ========================================================================

figure

semilogy(T,Jdiff,'r','LineWidth',2)

hold on

semilogy(T,Jsrh,'b','LineWidth',2)

grid on
box on

xlabel('Temperature (K)')
ylabel('Current (A/cm^2)')

legend('Diffusion','SRH','Location','northwest')

title('Diffusion vs SRH')

set(gca,'FontSize',12)

%% ========================================================================
% DISPLAY VALUES
% ========================================================================

disp('--------------------------------------------')
disp('Bandgap')
disp(Eg)

disp('--------------------------------------------')
disp('Diffusion Current')
disp(Jdiff)

disp('--------------------------------------------')
disp('SRH Current')
disp(Jsrh)
%% ========================================================================
% PART 2 : TAT CURRENT + AUGER CURRENT + TOTAL DARK CURRENT
% ========================================================================

%% ========================================================================
% REVERSE BIAS
% ========================================================================

V = linspace(0,0.5,100);     % Reverse Bias (Volt)

d = 5e-4;                    % Detector Thickness (cm)

Efield = V./d;               % Electric Field (V/cm)

Efield(Efield==0)=1;         % Avoid divide by zero

%% ========================================================================
% TAT CURRENT vs BIAS
% ========================================================================

C = 1e-10;
BTAT = 2e4;

Jtat_bias = C .* Efield .* exp(-BTAT./Efield);

figure

semilogy(V,Jtat_bias,'m','LineWidth',2)

grid on
box on

xlabel('Reverse Bias (V)')
ylabel('TAT Current (A/cm^2)')

title('TAT Current vs Reverse Bias')

set(gca,'FontSize',12)

%% ========================================================================
% TAT CURRENT vs TEMPERATURE
% ========================================================================

Vfixed = 0.2;          % Fixed Reverse Bias

Efixed = Vfixed/d;

Jtat = C .* exp(-BTAT/Efixed) .* exp(-Eg./(2*k*T));

figure

semilogy(T,Jtat,'m','LineWidth',2)

grid on
box on

xlabel('Temperature (K)')
ylabel('TAT Current (A/cm^2)')

title('TAT Current vs Temperature')

set(gca,'FontSize',12)

%% ========================================================================
% AUGER CURRENT
% ========================================================================

D = 1e-6;

Jauger = D .* (T.^4) .* exp(-Eg./(k*T));

figure

semilogy(T,Jauger,'g','LineWidth',2)

grid on
box on

xlabel('Temperature (K)')
ylabel('Auger Current (A/cm^2)')

title('Auger Current')

set(gca,'FontSize',12)

%% ========================================================================
% TOTAL DARK CURRENT
% ========================================================================

Jtotal = Jdiff + Jsrh + Jtat + Jauger;

figure

semilogy(T,Jtotal,'k','LineWidth',3)

grid on
box on

xlabel('Temperature (K)')
ylabel('Total Dark Current (A/cm^2)')

title('Total Dark Current')

set(gca,'FontSize',12)

%% ========================================================================
% ALL DARK CURRENT COMPONENTS
% ========================================================================

figure

semilogy(T,Jdiff,'r','LineWidth',2)

hold on

semilogy(T,Jsrh,'b','LineWidth',2)

semilogy(T,Jtat,'m','LineWidth',2)

semilogy(T,Jauger,'g','LineWidth',2)

semilogy(T,Jtotal,'k','LineWidth',3)

grid on
box on

xlabel('Temperature (K)')
ylabel('Current (A/cm^2)')

legend('Diffusion',...
       'SRH',...
       'TAT',...
       'Auger',...
       'Total',...
       'Location','northwest')

title('Dark Current Components')

set(gca,'FontSize',12)

%% ========================================================================
% DISPLAY
% ========================================================================

disp('----------------------------------')
disp('TAT Current')
disp(Jtat)

disp('----------------------------------')
disp('Auger Current')
disp(Jauger)

disp('----------------------------------')
disp('Total Dark Current')
disp(Jtotal)
%% ========================================================================
% PART 3 : nBn BARRIER EFFECT
% ========================================================================

%% Barrier Height Range

phi = 0:0.02:0.40;        % eV

Total77 = zeros(size(phi));

%% Barrier Optimization Loop

for i = 1:length(phi)

    % Diffusion suppression
    Jdiff_new = Jdiff .* exp(-phi(i)./(k*T));

    % TAT suppression
    Jtat_new = Jtat .* exp(-0.5*phi(i)./(k*T));

    % SRH and Auger unchanged
    Jnew = Jdiff_new + Jsrh + Jtat_new + Jauger;

    % Current at 77 K
    Total77(i) = Jnew(1);

end

%% ========================================================================
% Barrier Optimization Graph
% ========================================================================

figure

semilogy(phi,Total77,'b-o','LineWidth',2,...
    'MarkerFaceColor','b')

grid on
box on

xlabel('Barrier Height (eV)')
ylabel('Dark Current at 77 K (A/cm^2)')

title('Barrier Height Optimization')

set(gca,'FontSize',12)

%% ========================================================================
% Best Barrier
% ========================================================================

[minCurrent,index] = min(Total77);

BestBarrier = phi(index);

fprintf('\n')
fprintf('=====================================\n')
fprintf('Best Barrier Height = %.2f eV\n',BestBarrier)
fprintf('Minimum Dark Current = %e A/cm^2\n',minCurrent)
fprintf('=====================================\n')

%% ========================================================================
% nBn Current Using Best Barrier
% ========================================================================

Jdiff_nBn = Jdiff .* exp(-BestBarrier./(k*T));

Jtat_nBn = Jtat .* exp(-0.5*BestBarrier./(k*T));

Jsrh_nBn = Jsrh;

Jauger_nBn = Jauger;

Jtotal_nBn = Jdiff_nBn + ...
             Jsrh_nBn + ...
             Jtat_nBn + ...
             Jauger_nBn;

%% ========================================================================
% Conventional vs nBn
% ========================================================================

figure

semilogy(T,Jtotal,'r','LineWidth',2)

hold on

semilogy(T,Jtotal_nBn,'b','LineWidth',2)

grid on
box on

xlabel('Temperature (K)')
ylabel('Dark Current (A/cm^2)')

legend('Conventional HgCdTe',...
       'nBn HgCdTe',...
       'Location','northwest')

title('Conventional vs nBn')

set(gca,'FontSize',12)

%% ========================================================================
% Dark Current Reduction (%)
% ========================================================================

Reduction = ((Jtotal-Jtotal_nBn)./Jtotal)*100;

figure

plot(T,Reduction,'k','LineWidth',2)

grid on
box on

xlabel('Temperature (K)')
ylabel('Reduction (%)')

title('Dark Current Reduction by nBn')

set(gca,'FontSize',12)

%% ========================================================================
% 3D SURFACE
% ========================================================================

Barrier = 0:0.02:0.40;

[Tmesh,Bmesh] = meshgrid(T,Barrier);

Current3D = zeros(size(Tmesh));

for i=1:length(Barrier)

    Jtemp = Jdiff.*exp(-Barrier(i)./(k*T)) ...
          + Jsrh ...
          + Jtat.*exp(-0.5*Barrier(i)./(k*T)) ...
          + Jauger;

    Current3D(i,:) = Jtemp;

end

figure

surf(Tmesh,Bmesh,log10(Current3D))

shading interp

xlabel('Temperature (K)')
ylabel('Barrier Height (eV)')
zlabel('log_{10}(Dark Current)')

title('3D Dark Current Surface')

colorbar

%% ========================================================================
% CONTOUR PLOT
% ========================================================================

figure

contourf(Tmesh,Bmesh,log10(Current3D),20)

colorbar

xlabel('Temperature (K)')
ylabel('Barrier Height (eV)')

title('Dark Current Contour')

%% ========================================================================
% SAVE FIGURES
% ========================================================================

saveas(1,'Bandgap.png')
saveas(2,'Diffusion.png')
saveas(3,'SRH.png')
saveas(4,'Diffusion_vs_SRH.png')
saveas(5,'TAT_Bias.png')
saveas(6,'TAT_Temperature.png')
saveas(7,'Auger.png')
saveas(8,'Total_Dark_Current.png')
saveas(9,'Dark_Current_Components.png')
saveas(10,'Barrier_Optimization.png')
saveas(11,'Conventional_vs_nBn.png')
saveas(12,'Dark_Current_Reduction.png')
saveas(13,'3D_Surface.png')
saveas(14,'Contour.png')

disp(' ')
disp('=======================================')
disp('PROJECT COMPLETED SUCCESSFULLY')
disp('All graphs generated successfully.')
disp('=======================================')
clc
clear
close all

%% Physics Based Modeling of nBn HgCdTe Detector

%% Physical Constants

q = 1.602e-19;
k = 8.617e-5;
h = 6.626e-34;
c = 3e8;
eps0 = 8.854e-14;

%% Temperature

T = 77:5:300;

%% Cd Composition

x = 0.23;

%% Bandgap Equation

Eg = -0.302 + 1.93*x - 0.81*x^2 + 5.35e-4*T.*(1-2*x);

disp(Eg)
%% Diffusion Current

A = 1e-4;        % Model constant

Jdiff = A*(T.^3).*exp(-Eg./(k*T));
disp(Jdiff)
figure

semilogy(T,Jdiff,'r','LineWidth',3)

grid on

box on

xlabel('Temperature (K)')

ylabel('Diffusion Current (A/cm^2)')

title('Diffusion Dark Current')

set(gca,'FontSize',12)

saveas(gcf,'Diffusion_Current.png')

%% SRH Current

B = 5e-7;          % Model Constant

Jsrh = B*(T.^2).*exp(-Eg./(2*k*T));

disp(Jsrh)
figure

semilogy(T,Jsrh,'b','LineWidth',3)

grid on

box on

xlabel('Temperature (K)')

ylabel('SRH Current (A/cm^2)')

title('SRH Dark Current')

set(gca,'FontSize',12)

figure

semilogy(T,Jdiff,'r','LineWidth',3)

hold on

semilogy(T,Jsrh,'b','LineWidth',3)

grid on

box on

xlabel('Temperature (K)')

ylabel('Current (A/cm^2)')

title('Diffusion vs SRH')

legend('Diffusion','SRH')

set(gca,'FontSize',12)
%% Plot

figure

plot(T,Eg,'r','LineWidth',3)

grid on

box on

xlabel('Temperature (K)')

ylabel('Bandgap (eV)')

title('Bandgap vs Temperature')

set(gca,'FontSize',12)

saveas(gcf,'Bandgap.png')


%% Reverse Bias (Volt)
V = linspace(0,0.5,100);

%% Detector Thickness
d = 5e-4;          % cm (5 micron)

%% Electric Field
E = V/d;

% Avoid divide by zero
E(E==0) = 1;

%% TAT Model Constants
C = 1e-10;         % Constant
BTAT = 2e4;        % Constant

%% TAT Current
Jtat = C .* E .* exp(-BTAT ./ E);

%% Display Values
disp('Electric Field')
disp(E)

disp('TAT Current')
disp(Jtat)

%% Plot

figure

semilogy(V,Jtat,'r','LineWidth',2)

grid on
box on

xlabel('Reverse Bias (V)')
ylabel('TAT Current (A/cm^2)')
title('Trap Assisted Tunneling Current')

set(gca,'FontSize',12)
%% Temperature

T = 77:5:300;

%% TAT Constants

C = 1e-8;
BTAT = 2e4;

%% Fixed Reverse Bias

V = 0.2;          % Volt

d = 5e-4;         % cm

E = V/d;

%% TAT Current vs Temperature

Jtat = C .* exp(-BTAT./E) .* exp(-Eg./(2*k*T));

%% Plot

figure

semilogy(T,Jtat,'m','LineWidth',2)

grid on
box on

xlabel('Temperature (K)')
ylabel('TAT Current (A/cm^2)')
title('TAT Current vs Temperature')

figure

semilogy(T,Jdiff,'r','LineWidth',2)
hold on

semilogy(T,Jsrh,'b','LineWidth',2)

semilogy(T,Jtat,'m','LineWidth',2)

grid on
box on

xlabel('Temperature (K)')
ylabel('Current (A/cm^2)')

legend('Diffusion','SRH','TAT')

title('Dark Current Components')


% MODULE 5 : AUGER CURRENT

%% Temperature

T = 77:5:300;

%% Auger Constant

D = 1e-6;

%% Auger Current

Jauger = D*(T.^4).*exp(-Eg./(k*T));

%% Display

disp('Auger Current')
disp(Jauger)
figure

semilogy(T,Jauger,'g','LineWidth',2)

grid on
box on

xlabel('Temperature (K)')
ylabel('Auger Current (A/cm^2)')
title('Auger Current')

set(gca,'FontSize',12)
Jtotal = Jdiff + Jsrh + Jtat + Jauger;
figure

semilogy(T,Jtotal,'k','LineWidth',3)

grid on
box on

xlabel('Temperature (K)')
ylabel('Total Dark Current (A/cm^2)')
title('Total Dark Current')

set(gca,'FontSize',12)

figure

semilogy(T,Jdiff,'r','LineWidth',1)
hold on

semilogy(T,Jsrh,'b','LineWidth',1)

semilogy(T,Jtat,'m','LineWidth',2)

semilogy(T,Jauger,'g','LineWidth',1)

semilogy(T,Jtotal,'k','LineWidth',2)

grid on
box on

xlabel('Temperature (K)')
ylabel('Current (A/cm^2)')

legend('Diffusion','SRH','TAT','Auger','Total',...
    'Location','northwest')

title('Dark Current Components')

%% Barrier Height

phiB = 0.20;      % eV

%% nBn Current Components

Jdiff_nBn = Jdiff .* exp(-phiB./(k*T));

Jsrh_nBn = Jsrh;

Jtat_nBn = Jtat .* exp(-0.5*phiB./(k*T));

Jauger_nBn = Jauger;

%% Total nBn Dark Current

Jtotal_nBn = Jdiff_nBn + Jsrh_nBn + Jtat_nBn + Jauger_nBn;

%% Barrier Height vs Dark Current at 77 K

phi = 0:0.02:0.40;

for i = 1:length(phi)

    Jdiff_new = Jdiff .* exp(-phi(i)./(k*T));
    Jtat_new = Jtat .* exp(-0.5*phi(i)./(k*T));

    Jnew = Jdiff_new + Jsrh + Jtat_new + Jauger;

    Total77(i) = Jnew(1);

end

%% Conventional Dark Current at 77 K

Conventional77 = Jtotal(1);

%% Plot

figure

semilogy(phi,Conventional77*ones(size(phi)),'r--','LineWidth',3)

hold on

semilogy(phi,Total77,'b-','LineWidth',3)

grid on
box on

xlabel('Barrier Height (eV)')
ylabel('Dark Current at 77 K (A/cm^2)')

title('Barrier Height vs Dark Current at 77 K')

legend('Conventional HgCdTe','nBn HgCdTe',...
    'Location','best')

set(gca,'FontSize',12)
grid on
box on

xlabel('Barrier Height (eV)')
ylabel('Dark Current at 77 K (A/cm^2)')

title('Barrier Height vs Dark Current at 77 K')

legend('nBn HgCdTe','Location','best')

set(gca,'FontSize',12)

[~,index] = min(Total77);

BestBarrier = phi(index);

fprintf('Best Barrier Height = %.2f eV\n',BestBarrier);
disp('Conventional Dark Current at 77 K:')
disp(Jtotal(1))

disp('nBn Dark Current at 77 K:')
disp(Jtotal_nBn(1))
disp('Ratio Conventional/nBn:')
disp(Jtotal(1)/Jtotal_nBn(1))
%% Conventional vs nBn Dark Current

figure

semilogy(T, Jtotal, 'r-', 'LineWidth', 3)
hold on

semilogy(T, Jtotal_nBn, 'b--', 'LineWidth', 3)

grid on
box on

xlabel('Temperature (K)')
ylabel('Dark Current (A/cm^2)')

legend({'Conventional HgCdTe','nBn HgCdTe'}, ...
    'Location','northwest')

title('Conventional vs nBn Dark Current')

set(gca,'FontSize',12)



for i=1:length(phi)

    Jdiff_new = Jdiff .* exp(-phi(i)./(k*T));

    Jtat_new = Jtat .* exp(-0.5*phi(i)./(k*T));

    Jnew = Jdiff_new + Jsrh + Jtat_new + Jauger;

    Total77(i)=Jnew(1);

end

[minCurrent,index] = min(Total77);

BestBarrier = phi(index);

fprintf('Best Barrier Height = %.2f eV\n',BestBarrier);